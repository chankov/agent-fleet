---
name: spec-driven-development
description: Creates specs before coding. Use when starting a new project, feature, or significant change and no specification exists yet. Use when drafting a PRD or requirements document with objectives and scope, or when requirements are unclear, ambiguous, only exist as a vague idea, or need to be grilled before planning. Use when a single requirement spans several independently testable capabilities and needs decomposing into a capability map of modules before specifying.
---

# Spec-Driven Development

## Overview

Write a structured specification before writing any code. The spec is the shared source of truth between you and the human engineer — it defines what we're building, why, and how we'll know it's done. Code without a spec is guessing.

## When to Use

- Starting a new project or feature
- Requirements are ambiguous or incomplete
- The change touches multiple files or modules
- You're about to make an architectural decision
- The user asks to grill or stress-test a concept/spec before planning
- The task would take more than 30 minutes to implement

**When NOT to use:** Single-line fixes, typo corrections, or changes where requirements are unambiguous and self-contained.

## Proportionality gate (check before writing anything)

A spec is a commitment device: once it exists, everything in it gets planned, built, reviewed, and evidenced. That makes an oversized spec the most expensive mistake available here — it is cheaper to under-specify and ask than to over-specify and execute.

Before writing one, answer in one sentence: **what did the human actually ask for?** Then:

- **If the answer fits in a sentence and the change fits in a file, do not write a spec.** Make the change, state your assumptions, and let the human correct you. A one-line correction is cheaper than a spec review.
- **Spec the request, not the domain.** A request to fix how one service reads its configuration is not a mandate to specify that service's deployment, telemetry, and the retirement of its predecessor. Related work goes in a "Future / not now" list, not in scope.
- **Do not let non-goals grow the document.** A long list of things you will not do is not safety; it is surface area that later reviews will treat as requirements.
- **Verification must be proportionate.** Ask what evidence the human would actually want to see. "The tests pass and the app starts" is a complete verification story for most changes; per-item runtime provenance is warranted only when the human asked for it or the change is irreversible.
- **If the spec grows past the ask while you write it, stop and check in.** Say what it grew into and let the human choose the scope. A spec that outgrew its request is a finding, not a deliverable.

## Output Location

By default, save the spec to `docs/prds/{area}/PRD{n}-{topic}.md`:

- `{area}` — the functional area of the codebase the change belongs to. Ask the user or infer it from the change (e.g. `tournaments`, `calendar`, `auth`).
- `{n}` — the next free PRD number. Scan `docs/prds/` recursively for the highest existing `PRD<number>` and add 1; start at `1` if none exist.
- `{topic}` — a short kebab-case slug of the feature.

Match the project's existing `docs` vs `Docs` capitalization, and create the directory if it does not exist.

**Project overrides:** if `.ai/agent-fleet-overrides.md` has a `## spec-driven-development` section, its keys (`spec-dir`, `naming`) override these defaults. Absent file or section → use the defaults above. See [docs/agent-fleet-setup.md](../../docs/agent-fleet-setup.md).

## The Gated Workflow

Spec-driven development has four phases, preceded by a scope check (Phase 0) that activates only when one request bundles several independently testable capabilities. Do not advance to the next phase until the current one is validated.

```
SPECIFY ──→ PLAN ──→ TASKS ──→ IMPLEMENT
   │          │        │          │
   ▼          ▼        ▼          ▼
 Human      Human    Human      Human
 reviews    reviews  reviews    reviews
```

### Phase 0: Scope Check

Most requests describe one capability. If this one does, skip this phase and go straight to Specify — Phase 0 exists for the exception, not the rule, and it puts no hierarchy on single-capability features.

**Detection.** Decompose before specifying when a single requirement bundles several independently testable capabilities:

- The requirement names distinct capabilities with their own consumers or data (e.g. identity, billing, notifications, reporting)
- Acceptance criteria cluster into groups that could ship and be verified separately
- One capability could be cut or replaced without rewriting the others' requirements

**Propose a capability map before writing any spec.** Small and reviewable — a module table plus a build order, not a project plan:

```markdown
# Capability Map: [Initiative Name]

| Module id | Responsibility | Depends on |
|---|---|---|
| identity | Accounts, sessions, SSO | — |
| billing | Plans, invoices, payments | identity |
| notifications | Email and webhook fan-out | identity |
| reporting | Usage dashboards | billing, notifications |

Build order: identity → billing, notifications → reporting
```

- **Stable module ids.** Kebab-case, chosen once, never renamed mid-initiative. Specs, plans, and downstream commands select work by these ids instead of guessing which spec is active.
- **Dependency direction, no cycles.** Arrows point one way. If two modules each need the other, they are one module.
- **Interfaces live at the boundary.** The map records that `billing` depends on `identity`; the contract between them belongs in the provider module's spec (see `api-and-interface-design` for designing it).

**The map is gated like every phase.** The human reviews module boundaries, dependency direction, and build order before any module spec is written. Getting the map wrong is expensive; reviewing ten lines is not.

**Then recurse per module.** Run Specify → Plan → Tasks → Implement for each module in dependency order. Each module gets its own spec, scoped to that module's objective, boundaries, and success criteria. Save the approved map in the same spec directory the Output Convention above resolves to (default `docs/prds/{area}/`), as `CAPABILITY-MAP-{topic}.md`, and give each module its own PRD under the project's normal naming with the module id as the `{topic}` slug. The map, not filename guessing, is the index of what exists.

### Phase 1: Specify

**Gather context first.** Before writing any spec content, identify and read the sources the spec will build on:

- Existing documentation (README, architecture docs, ADRs)
- Related or prior specs — the new spec should explicitly link them (see `Related Specs` below)
- Code paths the change will touch, for implementation-oriented specs
- External artifacts the spec references (contract, design doc, ticket, research notes)

Writing a spec without reading what already exists leads to duplication, contradiction, and invented detail. If a source is missing or inaccessible, record it as an open question rather than guessing.

Then start with a high-level vision. Ask the human clarifying questions until requirements are concrete.

**Grilling (required before locking the spec):** Read the shared internal helper at [`../_internal/grilling.md`](../_internal/grilling.md). Skip anything already explicit in chat, prompt, PRD, or rules — do not re-confirm it. Research discoverable facts and resolve routine technical choices independently, recording their basis. Grill only unresolved material decisions one question at a time with a recommended option; specialists route questions through the orchestrator first. Multiple valid ways or competing local patterns alone do not require human input. Fold each answer into Success Criteria, Boundaries, Proposed decisions, or Open Questions. If nothing is open, note that grilling found no unspecified forks and continue.

**Surface assumptions immediately.** Before writing any spec content, classify what you would otherwise assume:

- Already explicit in chat, prompt, or rules → do not re-ask.
- Confirmed in code, tests, or trusted docs (e.g. PostgreSQL because the Prisma schema is already Postgres) → do not re-ask; mark Confirmed.
- Load-bearing and still open (native vs web, cookies vs JWT when neither is mandated) → grill per the helper above and **wait**. Do not dump a list and proceed unless corrected.

Don't silently fill in ambiguous requirements. The spec's entire purpose is to surface misunderstandings *before* code gets written — assumptions are the most dangerous form of misunderstanding.

**Ground every claim.** Every statement in the spec must fall into exactly one of these four categories, and the category should be clear to the reader:

- **Confirmed** — verified in code, tests, runtime, or trusted documentation. Safe to build on.
- **Target** — what we intend to build. Marked explicitly so it's not confused with current behavior.
- **Proposed** — a design decision that hasn't been approved yet. Must be reviewed before implementation.
- **Inferred** — a reasonable guess from available evidence, labeled as such. Ask to confirm if it load-bears a decision.

If a claim doesn't fit any of these categories, it belongs in **Open Questions**, not in the spec body. Mixing confirmed facts with proposals is how specs quietly become fiction.

**Do not invent.** Do not fabricate APIs, schemas, libraries, endpoints, file paths, environment variables, or commands. If the spec needs something that doesn't exist in the codebase or documentation yet, mark it as Proposed or add it to Open Questions. A spec that invents details becomes a source of bugs — downstream code gets written against things that were never real.

**Write a spec document covering these six core areas:**

1. **Objective** — What are we building and why? Who is the user? What does success look like?

2. **Commands** — Full executable commands with flags, not just tool names.
   ```
   Build: npm run build
   Test: npm test -- --coverage
   Lint: npm run lint --fix
   Dev: npm run dev
   ```

3. **Project Structure** — Where source code lives, where tests go, where docs belong.
   ```
   src/           → Application source code
   src/components → React components
   src/lib        → Shared utilities
   tests/         → Unit and integration tests
   e2e/           → End-to-end tests
   docs/          → Documentation
   ```

4. **Code Style** — One real code snippet showing your style beats three paragraphs describing it. Include naming conventions, formatting rules, and examples of good output.

5. **Testing Strategy** — What framework, where tests live, coverage expectations, which test levels for which concerns.

6. **Boundaries** — Three-tier system:
   - **Always do:** Run tests before commits, follow naming conventions, validate inputs
   - **Ask first:** Database schema changes, adding dependencies, changing CI config
   - **Never do:** Commit secrets, edit vendor directories, remove failing tests without approval

**Spec template:**

```markdown
# Spec: [Project/Feature Name]

## Objective
[What we're building and why. User stories or acceptance criteria.]

## Related Specs
- Refines: [path/to/prior-spec.md]
- Supersedes: [path/to/old-spec.md]
- Related: [path/to/adjacent-spec.md]

## Tech Stack
[Framework, language, key dependencies with versions]

## Commands
[Build, test, lint, dev — full commands]

## Project Structure
[Directory layout with descriptions]

## Code Style
[Example snippet + key conventions]

## Testing Strategy
[Framework, test locations, coverage requirements, test levels]

## Boundaries
- Always: [...]
- Ask first: [...]
- Never: [...]

## Success Criteria
[How we'll know this is done — specific, testable conditions]

## Open Questions
[Anything unresolved that needs human input]
```

**Reframe instructions as success criteria.** When receiving vague requirements, translate them into concrete conditions:

```
REQUIREMENT: "Make the dashboard faster"

REFRAMED SUCCESS CRITERIA:
- Dashboard LCP < 2.5s on 4G connection
- Initial data load completes in < 500ms
- No layout shift during load (CLS < 0.1)
→ Are these the right targets?
```

This lets you loop, retry, and problem-solve toward a clear goal rather than guessing what "faster" means.

### Phase 2: Plan

With the validated spec, generate a technical implementation plan:

1. Identify the major components and their dependencies
2. Determine the implementation order (what must be built first)
3. Note risks and mitigation strategies
4. Identify what can be built in parallel vs. what must be sequential
5. Define verification checkpoints between phases

> Follow `planning-and-task-breakdown` for the dependency-graph mapping and vertical-slicing mechanics behind these steps; it is the canonical source. The bullets above are a lightweight summary; if they ever diverge, `planning-and-task-breakdown` takes precedence.

The plan should be reviewable: the human should be able to read it and say "yes, that's the right approach" or "no, change X."

### Phase 3: Tasks

Break the plan into discrete, implementable tasks:

- Each task should be completable in a single focused session
- Each task has explicit acceptance criteria
- Each task includes a verification step (test, build, manual check)
- Tasks are ordered by dependency, not by perceived importance
- No task should require changing more than ~5 files

> Follow `planning-and-task-breakdown` for the full task-sizing and dependency-ordering mechanics; it is the canonical source. The template below is a lightweight inline form; if they ever diverge, `planning-and-task-breakdown` takes precedence.

**Task template:**
```markdown
- [ ] Task: [Description]
  - Acceptance: [What must be true when done]
  - Verify: [How to confirm — test command, build, manual check]
  - Files: [Which files will be touched]
```

### Phase 4: Implement

Execute tasks one at a time following `skills/incremental-implementation/SKILL.md` (`incremental-implementation`) and `skills/test-driven-development/SKILL.md` (`test-driven-development`). Use `skills/context-engineering/SKILL.md` (`context-engineering`) to load the right spec sections and source files at each step rather than flooding the agent with the entire spec.

## Keeping the Spec Alive

The spec is a living document, not a one-time artifact:

- **Update when decisions change** — If you discover the data model needs to change, update the spec first, then implement.
- **Update when scope changes** — Features added or cut should be reflected in the spec.
- **Commit the spec** — The spec belongs in version control alongside the code.
- **Reference the spec in PRs** — Link back to the spec section that each PR implements.

## Common Rationalizations

| Rationalization | Reality |
|---|---|
| "This is simple, I don't need a spec" | Simple tasks don't need *long* specs, but they still need acceptance criteria. A two-line spec is fine. |
| "I'll write the spec after I code it" | That's documentation, not specification. The spec's value is in forcing clarity *before* code. |
| "The spec will slow us down" | A 15-minute spec prevents hours of rework. Waterfall in 15 minutes beats debugging in 15 hours. |
| "Requirements will change anyway" | That's why the spec is a living document. An outdated spec is still better than no spec. |
| "The user knows what they want" | Even clear requests have implicit assumptions. The spec surfaces those assumptions. |
| "It's one big feature; splitting it is overhead" | If acceptance criteria cluster into independently testable groups, a monolithic spec forces every downstream task to reason over the whole contract. A ten-line capability map is the cheap alternative. |
| "I'll decompose during planning" | Planning slices tasks within a spec. By then the oversized artifact already exists — module boundaries and dependency direction must be decided before the spec is written, not after. |

## Red Flags

- Starting to write code without any written requirements
- Asking "should I just start building?" before clarifying what "done" means
- Implementing features not mentioned in any spec or task list
- Making architectural decisions without documenting them
- Skipping the spec because "it's obvious what to build"
- Re-asking a requirement already explicit in chat, prompt, or rules
- Locking a spec that silently picks among several valid approaches
- One spec whose requirements span several independently testable capabilities
- Module boundaries or build order decided implicitly during implementation because no capability map was approved up front

## Verification

Before proceeding to implementation, confirm:

- [ ] The spec covers all six core areas
- [ ] The human has reviewed and approved the spec
- [ ] Grilling ran before the spec was locked (inventory of load-bearing decisions)
- [ ] Already-stated requirements (chat, prompt, rules) were not re-asked
- [ ] Each remaining load-bearing decision is recorded as accepted, rejected, or deferred
- [ ] Success criteria are specific and testable
- [ ] Boundaries (Always/Ask First/Never) are defined
- [ ] The spec is saved to its output location (see Output Location)
- [ ] If the request bundles several independently testable capabilities, a capability map (module ids, dependency direction, build order) was approved before any module spec was written
- [ ] Every module spec traces to a module id in the approved map
