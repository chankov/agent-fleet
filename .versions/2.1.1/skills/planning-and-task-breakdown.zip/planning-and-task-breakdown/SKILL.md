---
name: planning-and-task-breakdown
description: Breaks work into a sequential implementation plan and grills unresolved material design decisions before writing tasks. Use when you have a spec or clear requirements and need locally verifiable implementation tasks. A plan is an implementation plan unless the human explicitly asks for another kind. Close one task before starting the next. Do not include environment, operator, deploy, publish, activation, or rollout work.
---

# Planning and Task Breakdown

## Overview

Decompose work into small, verifiable tasks with explicit acceptance criteria. Good task breakdown is the difference between an agent that completes work reliably and one that produces a tangled mess. Every task should be small enough to implement, test, and verify in a single focused session.

Unless the human explicitly asks for another kind of plan (research, migration design, retirement, or a deployment checklist), the plan is an **implementation plan**: ordered work to implement the stated requirements and verify them locally. Do not add a rollout, publish, delivery, or deployment phase. Do not add any task whose closure requires an environment, an operator, deploy, publish, activation, a post-deploy script, live mail, a live queue, or any other runtime that is not a local check. Those items are not numbered tasks. Mention them at most once, under "Out of scope / noticed", as belonging to a separate deployment checklist. Do not write that checklist unless the human explicitly asked for a deployment plan.

Tasks are a sequence, not a parallel batch. Close task N — its acceptance criteria met and its local verification done — before starting task N+1. A checkpoint is a gate after closed tasks, not permission to run several tasks at once. Vertical slices describe the shape of each task (one complete, locally testable path). They are not permission to execute slices in parallel. Parallel execution is allowed only when the human explicitly asks for it.

Do not choose how the plan will be executed. Do not ask whether to run it slice by slice or at once, and do not infer that from plan size or a worktree. Do not write `Execution: whole-plan` yourself. At execution time, `incremental-implementation` keeps per-slice human review unless the operator explicitly requests whole-plan execution. A checkpoint's human review applies only to that default. When the operator has already opted in, a checkpoint is local verification only. An unresolved material plan or PRD decision during execution still interrupts and is grilled with `ask_user`. This skill does not waive that.

## When to Use

- You have a spec and need to break it into implementable units
- A task feels too large or vague to start
- You need to communicate scope to a human
- The implementation order isn't obvious
- An unresolved material decision must be settled before dependent tasks are written; equivalent local patterns are routine technical choices

**When NOT to use:** Single-file changes with obvious scope, or when the spec already contains well-defined tasks. Skipping a plan file does **not** skip grilling: resolve routine technical choices independently; ask before coding only when an unresolved material decision affects the work.

## Proportionality gate (check before writing anything)

A plan is overhead the human pays for. Before you write one, size it against the ask:

| The ask | The right artifact |
|---|---|
| One obvious change, one file, low risk | **No plan.** Make the change and say what you did. |
| A contained change in familiar code | A task list in your reply — 3–6 lines, no plan file. |
| Multi-step work, unfamiliar code, or real risk | A plan file, as below. |

Rules that follow from this:

- **Never write a plan longer than the work it plans.** If the plan document would take longer to read than the change takes to make, it is the wrong artifact.
- **A safety requirement is a task, not a subsystem.** "Don't remove existing permissions" is one acceptance criterion with one verification step — not a hash-pinned manifest, an immutable evidence namespace, and a fixture suite. Provenance machinery is warranted only when the human asked for an audit trail or the change is irreversible at scale.
- **Plan the ask, not the neighbourhood.** Adjacent problems you notice go in a short "Out of scope / noticed" list at the end for the human to decide on. They do not become tasks.
- **Split by phase when the phases have different owners.** Repository work, cloud/infrastructure preparation, deployment, and retirement belong in separate plans only when the human explicitly asks for that other plan. An implementation plan does not include those phases. Bundling them blocks the whole plan on whichever phase stalls, and every review re-reads all of it.
- **No task that cannot close locally.** If closing the task needs a deployed or shared environment, an operator action, schema publish, a post-deploy script, activation, live mail, or a live queue, it is not an implementation task. Naming it "verification", "follow-up", or "rollout" does not make it one. Leave it off the task list.
- **Review findings do not silently enlarge the plan.** When a plan revision adds requirements nobody asked for, say so explicitly and let the human accept or drop them.
- **Unspecified forks still get grilled.** Skipping a plan file does not skip a load-bearing choice. Already-stated requirements (chat, prompt, PRD, rules) are not re-asked.

## Output Location

By default, save the plan to `docs/plans/{area}/PLAN-{prd-name}-{phase}.md`:

- `{area}` — the functional area; match the area of the PRD this plan implements.
- `{prd-name}` — the name of the PRD this plan implements (e.g. `PRD3-tournament-copy`). If there is no PRD, use a short kebab-case topic slug instead.
- `{phase}` — include a phase suffix **only** when the plan is deliberately split across more than one plan file. For a single-file plan, drop it (`PLAN-{prd-name}.md`).

The task list is **embedded** in the plan file as the `## Task List` section. Do **not** create a separate `todo.md`.

Match the project's existing `docs` vs `Docs` capitalization, and create the directory if it does not exist.

**Project overrides:** if `.ai/agent-fleet-overrides.md` has a `## planning-and-task-breakdown` section, its keys (`plan-dir`, `naming`, `todo`) override these defaults — `todo: separate` restores a standalone `todo.md`, and `todo: tracker` routes tasks to an external issue tracker (below). See [docs/agent-fleet-setup.md](../../docs/agent-fleet-setup.md).

### Task List Target

The **task list target** is where tasks and checkpoints are recorded. It is defined once, here; every other reference in this skill defers to it.

- **Default (`todo: embedded`)** — the `## Task List` section of the plan file itself. No separate file.
- **`todo: separate`** — a standalone checklist-style `todo.md` next to the plan.
- **`todo: tracker`** — one item per task in the designated issue tracker (GitHub Issues, Jira, Linear, `bd`/beads). Map the Step 4 structure onto the tracker's fields: acceptance criteria and verification steps in the item body, dependencies via the tracker's linking mechanism (`bd dep add`, "blocked by", etc.). Record Step 5 checkpoints as tracker items too, or keep them as a checklist in the plan document if the tracker has no natural equivalent.

With a tracker, name it in the plan (e.g. "Tasks tracked in Linear project FOO") so downstream steps and future sessions know where to look, and keep the plan's `## Task List` section as an ordered index of tracker item IDs or links rather than a duplicate checklist.

**Never overwrite an incomplete plan.** Before writing the resolved plan path, check whether it already exists and still contains unchecked tasks:

- Same work being replanned (the user asked to revise or extend this plan) → update the existing file in place.
- Different work → **stop and ask.** The unchecked tasks may be mid-build in another session or another flow worktree. Do not delete, overwrite, or rename the existing plan on your own; present the conflict and let the user decide (finish the old plan first, explicitly discard it, or say where the new plan should go).

The same rule applies to a tracker target: never bulk-close or delete another plan's open items to make room for new ones.

## The Planning Process

### Step 1: Enter Plan Mode

Before writing any code, operate in read-only mode:

- Read the spec and relevant codebase sections
- Identify existing patterns and conventions
- Map dependencies between components
- Note risks and unknowns

**Do NOT write code during planning.** The output is a plan document and a task list recorded in the task list target (see Output Location), not implementation.

**Grilling (required before writing tasks):** Read the shared internal helper at [`../_internal/grilling.md`](../_internal/grilling.md). Inventory load-bearing decisions. Skip anything already explicit in chat, prompt, PRD, spec, or rules. Research facts and decide routine implementation choices independently, recording their basis. Grill only unresolved material decisions one question at a time, with a recommended option; specialists route questions through the orchestrator first. Multiple valid ways alone do not require human input. Do not write tasks while a load-bearing choice is still silently assumed. Update Architecture Decisions, Risks, and Open Questions with accepted, rejected, or deferred choices. If nothing is open, note that grilling found no unspecified forks and continue.

**Model poll (planner, when `delegate` is available):** On an unresolved architectural fork at task tier `feature` or `project`, run `voice-1`, `voice-2`, and `voice-3` **after** recon (`scout`/`rules`), never in the same message, with a character-for-character identical instruction. Do not poll on `trivial`/`small` (delegation is off) and do not invent a poll if `delegate` is missing. Agreement informs a recommendation; it does not settle a material decision on behalf of the human. Record the voices; write a `POLL-{prd-name}.md` digest next to the plan and cite it. An unresolved material decision becomes one `ASK_USER:` question for orchestrator triage with one option per position plus a recommendation and reason — do not write the plan in that same turn. The optional communication contract at [`../../references/communication-contract.md`](../../references/communication-contract.md) is not loaded automatically; enable it with `append-prompt: references/communication-contract.md` in `## agent-hub`.

### Step 2: Identify the Dependency Graph

Map what depends on what:

```
Database schema
    │
    ├── API models/types
    │       │
    │       ├── API endpoints
    │       │       │
    │       │       └── Frontend API client
    │       │               │
    │       │               └── UI components
    │       │
    │       └── Validation logic
    │
    └── Seed data / migrations
```

Implementation order follows the dependency graph bottom-up: build foundations first.

### Step 3: Slice Vertically

Instead of building all the database, then all the API, then all the UI — build one complete feature path at a time:

**Bad (horizontal slicing):**
```
Task 1: Build entire database schema
Task 2: Build all API endpoints
Task 3: Build all UI components
Task 4: Connect everything
```

**Good (vertical slicing):**
```
Task 1: User can create an account (schema + API + UI for registration)
Task 2: User can log in (auth schema + API + UI for login)
Task 3: User can create a task (task schema + API + UI for creation)
Task 4: User can view task list (query + API + UI for list view)
```

Each vertical slice delivers working, locally testable functionality. "Locally testable" means tests, builds, and checks that run without a deployed environment or an operator.

Execute slices strictly in order. Finish and close one slice — acceptance criteria and local verification — before opening the next. Do not schedule independent slices as a parallel batch. Looking independent is not permission to parallelize.

### Step 4: Write Tasks

Each task follows this structure, whether it lands in the plan's `## Task List`, a standalone `todo.md`, or an external tracker item (see Output Location):

```markdown
## Task [N]: [Short descriptive title]

**Description:** One paragraph explaining what this task accomplishes.

**Acceptance criteria:**
- [ ] [Specific, testable condition]
- [ ] [Specific, testable condition]

**Verification:**
- [ ] Tests pass: [the project's `quality:` command, or the repository's focused-test command]
- [ ] Build succeeds: [the repository's build command]
- [ ] Local manual check, if needed: [description of what to verify without an environment or an operator]

**Dependencies:** [Task numbers this depends on, or "None"]

**Closes locally:** Yes. Acceptance and verification use only local tests, builds, and static checks. If this task cannot close without an environment, an operator, deploy, publish, activation, a post-deploy script, live mail, or a live queue, delete it from this plan.

**Files likely touched:**
- `src/path/to/file.ts`
- `tests/path/to/test.ts`
```

### Step 5: Order and Checkpoint

Arrange tasks so that:

1. Dependencies are satisfied (build foundation first)
2. Each task leaves the system in a working state
3. Verification checkpoints occur after every 2-3 closed tasks
4. High-risk tasks are early (fail fast)
5. The next task does not start until the previous task is closed. Do not mark a set of tasks as parallelizable unless the human explicitly asked for parallel execution

Add explicit checkpoints to the task list target:

```markdown
## Checkpoint: After Tasks 1-3
- [ ] All tests pass
- [ ] Application builds without errors
- [ ] Core user flow works end-to-end in local tests or a local run
- [ ] Review with human before starting the next task (default execution only; when the operator has explicitly requested whole-plan execution, this line is local verification only)
- [ ] No later task was started before this checkpoint's tasks were closed
```

## Task Sizing Guidelines

If a task is 5-8 files (Multi-component feature , such as Search with filtering and pagination) or larger, it should be broken into smaller tasks. An agent performs best on 1-5 file tasks.

**When to break a task down further:**
- It would take more than one focused session (roughly 2+ hours of agent work)
- You cannot describe the acceptance criteria in 3 or fewer bullet points
- It touches two or more independent subsystems (e.g., auth and billing)
- You find yourself writing "and" in the task title (a sign it is two tasks)

## Plan Document Template

```markdown
# Implementation Plan: [Feature/Project Name]

## Overview
[One paragraph summary of what we're building]

## Architecture Decisions
- [Key decision 1 and rationale]
- [Key decision 2 and rationale]

## Task List

Execution is strictly sequential. Close one task before starting the next. No parallel batch.

### Phase 1: Foundation
- [ ] Task 1: ...
- [ ] Task 2: ...

### Checkpoint: Foundation
- [ ] Local tests pass, builds clean

### Phase 2: Core Features
- [ ] Task 3: ...
- [ ] Task 4: ...

### Checkpoint: Core Features
- [ ] End-to-end flow works

### Phase 3: Polish
- [ ] Task 5: ...
- [ ] Task 6: ...

### Checkpoint: Complete
- [ ] All acceptance criteria met
- [ ] Ready for review

## Risks and Mitigations
| Risk | Impact | Mitigation |
|------|--------|------------|
| [Risk] | [High/Med/Low] | [Strategy] |

## Open Questions
- [Question needing human input]
```

When tasks live in an external tracker, keep the Task List section above as an ordered index of tracker item IDs or links instead of a duplicate checklist.

## Parallel execution is not the default

Do not plan tasks for parallel agents or sessions unless the human explicitly asks for parallel execution.

- **Default:** one ordered sequence. Close the current task before starting the next, including when several slices look independent.
- **Explicit parallel request only:** the human asked to parallelize. Even then, database migrations, shared-state changes, and dependency chains stay sequential. No parallel task may require an environment, an operator, deploy, or publish to close.
- **Deployment checklist:** not part of an implementation plan. Write one only when the human explicitly asks for a deployment or rollout plan. Do not append environment verification, operator actions, publish, activation, or delivery as the next numbered tasks.

## Common Rationalizations

| Rationalization | Reality |
|---|---|
| "I'll figure it out as I go" | That's how you end up with a tangled mess and rework. 10 minutes of planning saves hours. |
| "The tasks are obvious" | Write them down anyway. Explicit tasks surface hidden dependencies and forgotten edge cases. |
| "Planning is overhead" | Planning is the task. Implementation without a plan is just typing. |
| "I can hold it all in my head" | Context windows are finite. Written plans survive session boundaries and compaction. |
| "The old plan is stale, I'll just replace it" | Unchecked tasks may be mid-build in another session or flow worktree. Overwriting them destroys work state that exists nowhere else. Stop and ask. |
| "The PRD already covers everything, no need to grill" | Then grilling produces zero questions. Still run the inventory so silent forks do not slip through. |
| "I'll pick the obvious variant and note it in Architecture Decisions" | If more than one variant exists and none was mandated, it is not obvious to the programmer who was not in the room. Ask, then record the choice. |
| "Re-confirming the PRD points shows thoroughness" | Re-asking settled requirements wastes the user and implies the agent did not read them. Skip them. |
| "These slices are independent, so plan them in parallel" | Independence is not permission. Close one slice before the next unless the human explicitly asked to parallelize. |
| "The plan is small, or it will run on a worktree, so I'll record whole-plan" | No. The operator writes that opt-in. The planner does not ask which execution mode to use and does not infer it. |
| "The next tasks are just environment verification, not rollout" | If a task cannot close without an environment or an operator, it is not an implementation task. It belongs on a separate deployment checklist, not in this plan. |
| "The requirements mention deploy, so the implementation plan should include it" | A mention of deploy, publish, or delivery does not add those phases. Record them once under Out of scope unless the human explicitly asked for a deployment plan. |

## Red Flags

- Starting implementation without a written task list
- Overwriting a plan that still has unchecked tasks for different work, without asking
- Writing a `todo.md` when the project has designated an external tracker (or scattering tasks across both)
- Tasks that say "implement the feature" without acceptance criteria
- No verification steps in the plan
- All tasks touches more than 8+ files
- No checkpoints between tasks
- Dependency order isn't considered
- Writing tasks that silently pick a library, pattern, or behavior not mandated in chat/PRD/rules
- Re-asking a requirement already explicit in chat, prompt, PRD, spec, or rules
- Leaving an unresolved material decision as an Open Question while proceeding with dependent work
- Planning tasks as a parallel batch without an explicit human request to parallelize
- Asking, during planning, whether to execute the plan at once
- Writing `Execution: whole-plan` into the plan to waive the human review gate
- A rollout, publish, delivery, or deployment phase in an implementation plan
- A numbered task whose closure needs an environment, an operator, deploy, publish, activation, a post-deploy script, live mail, or a live queue
- Numbering deployment-checklist items as implementation tasks, including under a "verification" or "follow-up" heading

## Verification

Before starting implementation, confirm:

- [ ] Every task has acceptance criteria
- [ ] Every task has a verification step
- [ ] Task dependencies are identified and ordered correctly
- [ ] Tasks are recorded in the task list target resolved from `todo` (default: the plan's `## Task List`)
- [ ] No pre-existing incomplete plan was overwritten without explicit user confirmation
- [ ] No task touches more than ~5 files
- [ ] Checkpoints exist between major phases
- [ ] The human has reviewed and approved the plan
- [ ] Grilling ran before tasks were written (inventory of load-bearing decisions)
- [ ] Already-stated requirements (chat, prompt, PRD, spec, rules) were not re-asked
- [ ] Each remaining load-bearing decision has an accepted/rejected/deferred status in the plan
- [ ] No open questions left (All are resolved/answered/commented)
- [ ] The plan is an implementation plan unless the human explicitly asked for another kind
- [ ] Every task can close with local tests, builds, or static checks
- [ ] No task requires an environment, an operator, deploy, publish, activation, a post-deploy script, live mail, or a live queue
- [ ] Rollout, publish, delivery, and deployment are absent from the task list; if noticed, they appear at most once under Out of scope
- [ ] Tasks are ordered for sequential execution: each task closes before the next starts, unless the human explicitly asked to parallelize

## See Also

Acceptance criteria are per-task and answer "did we build the right thing?". They sit on top of the project-wide Definition of Done, the standing bar every task clears before it counts as done. See `../../references/definition-of-done.md`.
